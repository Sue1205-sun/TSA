import akshare as ak
import pandas as pd
import numpy as np
import torch
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset, DataLoader


def get_ssec_data(start_date="2015-01-01", end_date="2025-03-01"):

    print(f"正在使用 AkShare 获取上证指数数据 {start_date} 到 {end_date}...")

    start_str = start_date.replace("-", "")
    end_str = end_date.replace("-", "")

    try:
        df = ak.index_zh_a_hist(symbol="000001", period="daily", start_date=start_str, end_date=end_str)
    except Exception as e:
        raise RuntimeError(f"获取数据失败，请检查网络或 AkShare 库状态。错误信息: {e}")

    df.rename(columns={
        '日期': 'Date',
        '开盘': 'Open',
        '最高': 'High',
        '最低': 'Low',
        '收盘': 'Close',
        '成交量': 'Volume'
    }, inplace=True)

    df['Date'] = pd.to_datetime(df['Date'])
    df.set_index('Date', inplace=True)

    df = df[['Open', 'High', 'Low', 'Close', 'Volume']].copy()

    df.ffill(inplace=True)

    return df


def calculate_llm_sentiment_proxy(df):

    w1, w2, w3 = 0.4, 0.4, 0.2
    span_short, span_long, span_vol = 10, 50, 14

    mom_short = df['Close'].pct_change(periods=10)
    mom_long = df['Close'].pct_change(periods=50)

    log_returns = np.log(df['Close'] / df['Close'].shift(1))
    vol = log_returns.rolling(window=14).std()

    ema_mom_short = mom_short.ewm(span=span_short, adjust=False).mean()
    ema_mom_long = mom_long.ewm(span=span_long, adjust=False).mean()
    ema_vol = vol.ewm(span=span_vol, adjust=False).mean()

    sentiment_proxy = (w1 * ema_mom_short) + (w2 * ema_mom_long) - (w3 * ema_vol)

    df['LLM_Sentiment'] = sentiment_proxy

    df.dropna(inplace=True)
    return df


def create_sliding_windows(data, window_size=60):

    X, y = [], []
    # 如果包含情绪特征，Close 的索引是 3；如果不包含，也是 3
    close_idx = 3

    for i in range(len(data) - window_size):
        X.append(data[i: i + window_size, :])  # 包含所有特征
        y.append(data[i + window_size, close_idx])  # 仅预测收盘价

    return np.array(X), np.array(y)


def get_dataloaders(batch_size=64, window_size=60, train_ratio=0.8, start_date="2015-01-01", end_date="2025-03-01", include_sentiment=True):

    df = get_ssec_data(start_date, end_date)

    if include_sentiment:
        df = calculate_llm_sentiment_proxy(df)
    else:
        print("消融实验：跳过 LLM 情绪代理特征...")
        df.dropna(inplace=True)

    print("正在进行特征归一化与滑动窗口切分...")
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(df)

    X, y = create_sliding_windows(scaled_data, window_size)

    split_idx = int(len(X) * train_ratio)
    X_train, y_train = X[:split_idx], y[:split_idx]
    X_test, y_test = X[split_idx:], y[split_idx:]

    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32).unsqueeze(1)  # 增加一维: (batch_size) -> (batch_size, 1)

    X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
    y_test_tensor = torch.tensor(y_test, dtype=torch.float32).unsqueeze(1)

    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    test_dataset = TensorDataset(X_test_tensor, y_test_tensor)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    print("数据加载器准备完毕！")
    return train_loader, test_loader, scaler


# ================= 测试启动入口 =================
if __name__ == "__main__":
    # 调用主函数
    train_loader, test_loader, scaler = get_dataloaders(batch_size=64, window_size=60)

    # 提取一个 Batch 进行维度验证
    for batch_X, batch_y in train_loader:
        print("-" * 40)
        print("✅ 验证成功：")
        print(f"输入 X 张量形状 (Batch_Size, Window_Size, Features) : {batch_X.shape}")
        print(f"标签 y 张量形状 (Batch_Size, 1)                      : {batch_y.shape}")
        print("-" * 40)
        break