import os
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import torch
import torch.nn as nn
import math
import numpy as np
import warnings
from statsmodels.tsa.arima.model import ARIMA


warnings.filterwarnings("ignore", module="statsmodels")


# ==========================================
# 1. 基线模型：LSTM
# ==========================================
class BaselineLSTM(nn.Module):


    def __init__(self, d_input=6, hidden_size=64, num_layers=2, dropout=0.2):
        super(BaselineLSTM, self).__init__()

        self.hidden_size = hidden_size
        self.num_layers = num_layers


        self.lstm = nn.LSTM(
            input_size=d_input,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0
        )

        self.fc = nn.Linear(hidden_size, 1)

    def forward(self, x):

        out, (h_n, c_n) = self.lstm(x)

        last_step_out = out[:, -1, :]

        prediction = self.fc(last_step_out)

        return prediction


# ==========================================
# 2. 基线模型：Transformer (附带位置编码)
# ==========================================
class PositionalEncoding(nn.Module):


    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        seq_len = x.size(1)
        x = x + self.pe[:, :seq_len, :]
        return x


class BaselineTransformer(nn.Module):


    def __init__(self, d_input=6, d_model=64, nhead=4, num_layers=2, dim_feedforward=256, dropout=0.2):
        super(BaselineTransformer, self).__init__()

        self.embedding = nn.Linear(d_input, d_model)
        self.pos_encoder = PositionalEncoding(d_model)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.fc = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.embedding(x)
        x = self.pos_encoder(x)
        out = self.transformer_encoder(x)
        last_step_out = out[:, -1, :]
        prediction = self.fc(last_step_out)
        return prediction


# ==========================================
# 3. 基线模型：ARIMA
# ==========================================
class BaselineARIMA:


    def __init__(self, p=5, d=1, q=0):
        self.order = (p, d, q)

    def predict_rolling(self, train_close_series, test_close_series):

        print(f"正在运行 ARIMA{self.order} 滚动预测 (CPU 单核拟合中，请稍候)...")
        history = list(train_close_series)
        predictions = []

        total_steps = len(test_close_series)
        for t in range(total_steps):
            if (t + 1) % 50 == 0:
                print(f"ARIMA 进度: {t + 1}/{total_steps}")

            model = ARIMA(history, order=self.order)
            model_fit = model.fit()

            yhat = model_fit.forecast()[0]
            predictions.append(yhat)

            obs = test_close_series[t]
            history.append(obs)

        return np.array(predictions)


# ================= 测试代码 =================
if __name__ == "__main__":
    print("=======================================")
    print(" 正在测试所有基线模型接口")
    print("=======================================")

    batch_size = 64
    window_size = 60
    features = 6
    dummy_tensor_input = torch.randn(batch_size, window_size, features)

    lstm_model = BaselineLSTM(d_input=features)
    transformer_model = BaselineTransformer(d_input=features)

    lstm_out = lstm_model(dummy_tensor_input)
    print(f"✅ LSTM 模型通过验证！输出形状: {lstm_out.shape} (期望: [64, 1])")

    transformer_out = transformer_model(dummy_tensor_input)
    print(f"✅ Transformer 模型通过验证！输出形状: {transformer_out.shape} (期望: [64, 1])")


    dummy_train_series = np.random.randn(200)
    dummy_test_series = np.random.randn(5)

    arima_model = BaselineARIMA(p=1, d=1, q=0)
    arima_out = arima_model.predict_rolling(dummy_train_series, dummy_test_series)
    print(f"✅ ARIMA 模型通过验证！输出了 {len(arima_out)} 天的预测结果。")
