import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import math
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error

from data_loader import get_dataloaders
from model import ITSAMambaModel
from itsa_optimizer import ITSAOptimizer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"当前运行设备: {device}")


def train_eval_mamba(model, train_loader, val_loader=None, epochs=100, lr=1e-4, patience=10, is_fast_mode=False):

    model.to(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    best_val_loss = float('inf')
    patience_counter = 0

    for epoch in range(epochs):
        model.train()
        train_loss = 0.0

        for batch_X, batch_y in train_loader:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)

            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * batch_X.size(0)

        train_loss /= len(train_loader.dataset)

        if val_loader is not None:
            model.eval()
            val_loss = 0.0
            with torch.no_grad():
                for batch_X, batch_y in val_loader:
                    batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                    outputs = model(batch_X)
                    loss = criterion(outputs, batch_y)
                    val_loss += loss.item() * batch_X.size(0)
            val_loss /= len(val_loader.dataset)

            current_metric = math.sqrt(val_loss)

            if current_metric < best_val_loss:
                best_val_loss = current_metric
                patience_counter = 0
            else:
                patience_counter += 1

            if not is_fast_mode and patience_counter >= patience:
                print(f"🚀 触发早停机制，在 Epoch {epoch + 1} 停止。")
                break
        else:
            best_val_loss = math.sqrt(train_loss)

    return best_val_loss


def main():
    print("\n" + "=" * 50)
    print(" 步骤 1: 数据加载与特征构建")
    print("=" * 50)
    batch_size = 64
    window_size = 60
    train_loader, test_loader, scaler = get_dataloaders(batch_size=batch_size, window_size=window_size)


    close_idx = 3
    close_min = scaler.data_min_[close_idx]
    close_max = scaler.data_max_[close_idx]

    print("\n" + "=" * 50)
    print(" 步骤 2: 启动 ITSA 自动优选超参数")
    print("=" * 50)

    def itsa_objective_function(params):

        d_model = int(params[0])
        n_layer = int(params[1])
        d_state = int(params[2])
        d_conv = int(params[3])

        model = ITSAMambaModel(d_input=6, d_model=d_model, n_layer=n_layer, d_state=d_state, d_conv=d_conv)


        rmse = train_eval_mamba(model, train_loader, val_loader=train_loader, epochs=3, lr=1e-3, is_fast_mode=True)
        return rmse

    param_bounds = [
        (16, 64),  # d_model: [16, 64]
        (1, 4),  # n_layer: [1, 4]
        (8, 32),  # d_state: [8, 32]
        (2, 6)  # d_conv: [2, 6]
    ]

    optimizer = ITSAOptimizer(
        obj_func=itsa_objective_function,
        dim=4,
        pop_size=5,  # 种群 5
        max_gen=5,  # 迭代 5 次
        bounds=param_bounds
    )

    best_params, best_val, curve = optimizer.optimize()

    d_model_opt = int(best_params[0])
    n_layer_opt = int(best_params[1])
    d_state_opt = int(best_params[2])
    d_conv_opt = int(best_params[3])

    print("\nITSA 寻优完成！最优超参数：")
    print(f"d_model={d_model_opt}, n_layer={n_layer_opt}, d_state={d_state_opt}, d_conv={d_conv_opt}")

    # 3. 终极模型训练
    print("\n" + "=" * 50)
    print(" 步骤 3: 最终 ITSA-Mamba-LLM 模型的完整训练")
    print("=" * 50)

    final_model = ITSAMambaModel(
        d_input=6,
        d_model=d_model_opt,
        n_layer=n_layer_opt,
        d_state=d_state_opt,
        d_conv=d_conv_opt
    )

    train_eval_mamba(final_model, train_loader, val_loader=test_loader, epochs=100, lr=1e-4, patience=10,
                     is_fast_mode=False)

    print("\n" + "=" * 50)
    print(" 步骤 4: 模型评估 ")
    print("=" * 50)

    final_model.eval()
    preds_list = []
    trues_list = []

    with torch.no_grad():
        for batch_X, batch_y in test_loader:
            batch_X = batch_X.to(device)
            outputs = final_model(batch_X)

            outputs_np = outputs.cpu().numpy().flatten()
            batch_y_np = batch_y.numpy().flatten()

            preds_list.extend(outputs_np)
            trues_list.extend(batch_y_np)

    preds_arr = np.array(preds_list)
    trues_arr = np.array(trues_list)

    preds_real = preds_arr * (close_max - close_min) + close_min
    trues_real = trues_arr * (close_max - close_min) + close_min

    final_rmse = math.sqrt(mean_squared_error(trues_real, preds_real))
    final_mae = mean_absolute_error(trues_real, preds_real)
    final_mape = mean_absolute_percentage_error(trues_real, preds_real) * 100  # 转为百分比

    print("最终测试集评估指标 (单位: 上证指数点位):")
    print(f"RMSE : {final_rmse:.2f} pts")
    print(f"MAE  : {final_mae:.2f} pts")
    print(f"MAPE : {final_mape:.3f} %")
    print("\n论文核心框架复现全部完成！")


if __name__ == "__main__":
    main()