import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time
import math

try:
    import opfunu
except ImportError:
    print("缺少 opfunu 库！请在终端运行: pip install opfunu")
    exit()



def TSA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    N, D = pop_size, dim
    low, high = int(np.ceil(0.1 * N)), int(np.ceil(0.25 * N))
    ST = 0.1
    trees = np.random.uniform(lb, ub, (N, D))
    obj = np.array([obj_func(trees[i]) for i in range(N)])
    best_idx = np.argmin(obj)
    best, best_params = obj[best_idx], trees[best_idx].copy()
    convergence = np.zeros(max_gen)

    for t in range(max_gen):
        for i in range(N):
            ns = np.random.randint(low, high + 1)
            seeds = np.zeros((ns, D))
            r = np.random.randint(0, N)
            while r == i: r = np.random.randint(0, N)

            for j in range(ns):
                for d in range(D):
                    if np.random.rand() < ST:
                        seeds[j, d] = trees[i, d] + (best_params[d] - trees[r, d]) * (np.random.rand() - 0.5) * 2
                    else:
                        seeds[j, d] = trees[i, d] + (trees[i, d] - trees[r, d]) * (np.random.rand() - 0.5) * 2
                    if seeds[j, d] > ub or seeds[j, d] < lb:
                        seeds[j, d] = lb + (ub - lb) * np.random.rand()

            objs = np.array([obj_func(seeds[j]) for j in range(ns)])
            best_seed_idx = np.argmin(objs)
            if objs[best_seed_idx] < obj[i]:
                trees[i] = seeds[best_seed_idx].copy()
                obj[i] = objs[best_seed_idx]

        if np.min(obj) < best:
            best_idx = np.argmin(obj)
            best, best_params = obj[best_idx], trees[best_idx].copy()
        convergence[t] = best
    return best_params, best, convergence


def RSA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    T, N = max_gen, pop_size
    X = np.random.uniform(lb, ub, (N, dim))
    gbestVal = np.inf
    gbest = np.zeros(dim)
    convergence = np.zeros(T)
    Ffun = np.array([obj_func(X[i]) for i in range(N)])

    best_idx = np.argmin(Ffun)
    gbestVal, gbest = Ffun[best_idx], X[best_idx].copy()
    Alpha, Beta, eps = 0.1, 0.005, 1e-8

    for t in range(1, T + 1):
        ES = 2 * np.random.randn() * (1 - (t / T))
        Xnew = np.zeros((N, dim))
        for i in range(N):
            for j in range(dim):
                rand_idx = np.random.randint(0, N)
                R = gbest[j] - X[rand_idx, j] / (gbest[j] + eps)
                P = Alpha + (X[i, j] - np.mean(X[i, :])) / (gbest[j] * (ub - lb) + eps)
                Eta = gbest[j] * P

                if t < T / 4:
                    Xnew[i, j] = gbest[j] - Eta * Beta - R * np.random.rand()
                elif t < 2 * T / 4:
                    Xnew[i, j] = gbest[j] * X[rand_idx, j] * ES * np.random.rand()
                elif t < 3 * T / 4:
                    Xnew[i, j] = gbest[j] * P * np.random.rand()
                else:
                    Xnew[i, j] = gbest[j] - Eta * eps - R * np.random.rand()

        for i in range(N):
            Xnew[i] = np.clip(Xnew[i], lb, ub)
            f_new = obj_func(Xnew[i])
            if f_new < Ffun[i]:
                X[i], Ffun[i] = Xnew[i].copy(), f_new
            if Ffun[i] < gbestVal:
                gbestVal, gbest = Ffun[i], X[i].copy()
        convergence[t - 1] = gbestVal
    return gbest, gbestVal, convergence


def STSA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    N, D = pop_size, dim
    low, high = int(np.ceil(0.1 * N)), int(np.ceil(0.25 * N))
    ST, maxfes, fes = 0.1, D * 10000, N
    trees = np.random.uniform(lb, ub, (N, D))
    obj = np.array([obj_func(trees[i]) for i in range(N)])
    best_idx = np.argmin(obj)
    best, best_params = obj[best_idx], trees[best_idx].copy()
    convergence = np.zeros(max_gen)

    for t in range(max_gen):
        ratioFEs = fes / maxfes if fes < maxfes else 1.0
        xTheta = 0.5 * ratioFEs * np.pi
        k = 2 * (1 - ratioFEs)

        for i in range(N):
            ns_i = int(low + abs((high - low) * np.cos(xTheta))) + 1
            seeds = np.zeros((ns_i, D))
            komsu = np.random.randint(0, N)
            while i == komsu: komsu = np.random.randint(0, N)

            for j in range(ns_i):
                for d in range(D):
                    selectRand = np.random.rand()
                    if selectRand < 0.5 * ST:
                        tmpRand = np.random.rand()
                        seeds[j, d] = tmpRand * trees[komsu, d] + (1 - tmpRand) * best_params[d]
                    elif selectRand < ST:
                        seeds[j, d] = trees[i, d] + k * (best_params[d] - np.random.rand() * trees[i, d]) * np.sin(
                            np.pi * np.arccos(np.random.rand()))
                    else:
                        seeds[j, d] = np.random.rand() * trees[i, d] + k * (
                                    trees[komsu, d] - np.random.rand() * trees[i, d]) * np.sin(
                            np.pi * np.arccos(np.random.rand()))
                    seeds[j, d] = np.clip(seeds[j, d], lb, ub)

            objs = np.array([obj_func(seeds[j]) for j in range(ns_i)])
            best_seed_idx = np.argmin(objs)
            if objs[best_seed_idx] < obj[i]:
                trees[i], obj[i] = seeds[best_seed_idx].copy(), objs[best_seed_idx]
            fes += ns_i

        if np.min(obj) < best:
            best_idx = np.argmin(obj)
            best, best_params = obj[best_idx], trees[best_idx].copy()
        convergence[t] = best
    return best_params, best, convergence


def EST_TSA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    N, D = pop_size, dim
    seeds_lb, seeds_ub = int(np.ceil(N * 0.05)), int(np.ceil(N * 0.15))
    trees = np.random.uniform(lb, ub, (N, D))
    obj_trees = np.array([obj_func(trees[i]) for i in range(N)])
    best_idx = np.argmin(obj_trees)
    best, best_params = obj_trees[best_idx], trees[best_idx].copy()
    convergence = np.zeros(max_gen)

    for t in range(max_gen):
        for i in range(N):
            num_seeds = int(np.floor(seeds_lb + (seeds_ub - seeds_lb) * np.random.rand())) + 1
            seeds = np.zeros((num_seeds, D))
            for j in range(num_seeds):
                random_tree = np.random.randint(0, N)
                while i == random_tree: random_tree = np.random.randint(0, N)
                rand_t = np.random.rand()
                for d in range(D):
                    if j == 0:
                        r_val = np.random.rand()
                        seeds[j, d] = trees[i, d] + (trees[i, d] - (r_val - 0.5) * 2 * best_params[d]) * (
                                    rand_t - 0.5) * 2
                    else:
                        seeds[j, d] = trees[i, d] + (trees[i, d] - trees[random_tree, d]) * (np.random.rand() - 0.5) * 2
                    if seeds[j, d] > ub or seeds[j, d] < lb:
                        seeds[j, d] = lb + (ub - lb) * np.random.rand()

            obj_seeds = np.array([obj_func(seeds[j]) for j in range(num_seeds)])
            best_seed_idx = np.argmin(obj_seeds)
            if obj_seeds[best_seed_idx] < obj_trees[i]:
                trees[i], obj_trees[i] = seeds[best_seed_idx].copy(), obj_seeds[best_seed_idx]

        if np.min(obj_trees) < best:
            best_idx = np.argmin(obj_trees)
            best, best_params = obj_trees[best_idx], trees[best_idx].copy()
        convergence[t] = best
    return best_params, best, convergence


def BOA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    n, p, power_exponent, sensory_modality = pop_size, 0.8, 0.1, 0.01
    Sol = np.random.uniform(lb, ub, (n, dim))
    Fitness = np.array([obj_func(Sol[i]) for i in range(n)])
    fmin_idx = np.argmin(Fitness)
    fmin, best_pos = Fitness[fmin_idx], Sol[fmin_idx].copy()
    S, convergence = Sol.copy(), np.zeros(max_gen)

    for t in range(max_gen):
        for i in range(n):
            Fnew = obj_func(S[i])
            FP = sensory_modality * (abs(Fnew) ** power_exponent)
            if np.random.rand() < p:
                dis = np.random.rand(dim) * np.random.rand(dim) * best_pos - Sol[i]
                S[i] = Sol[i] + dis * FP
            else:
                epsilon = np.random.rand(dim)
                JK = np.random.permutation(n)
                dis = epsilon * epsilon * Sol[JK[0]] - Sol[JK[1]]
                S[i] = Sol[i] + dis * FP
            S[i] = np.clip(S[i], lb, ub)
            Fnew = obj_func(S[i])
            if Fnew <= Fitness[i]:
                Sol[i], Fitness[i] = S[i].copy(), Fnew
            if Fnew <= fmin:
                best_pos, fmin = S[i].copy(), Fnew
        convergence[t] = fmin
        sensory_modality = sensory_modality + (0.025 / (sensory_modality * max_gen))
    return best_pos, fmin, convergence


def GA_func(obj_func, dim, pop_size, max_gen, lb, ub):
    PopSize, MaxIteration = pop_size, max_gen
    CrossPercent, MutatPercent = 70, 20
    CrossNum = int(round(CrossPercent / 100.0 * PopSize))
    if CrossNum % 2 != 0: CrossNum -= 1
    MutatNum = int(round(MutatPercent / 100.0 * PopSize))
    ElitNum = PopSize - CrossNum - MutatNum

    Pop = np.random.uniform(lb, ub, (PopSize, dim))
    Cost = np.array([obj_func(Pop[i]) for i in range(PopSize)])
    sort_idx = np.argsort(Cost)
    Pop, Cost = Pop[sort_idx], Cost[sort_idx]
    convergence = np.zeros(MaxIteration)

    for Iter in range(MaxIteration):
        ElitPop = Pop[:ElitNum].copy()
        CrossPop = []
        for _ in range(CrossNum // 2):
            idx1, idx2 = np.random.choice(PopSize, 2, replace=False)
            alpha = np.random.rand(dim)
            off1 = np.clip(alpha * Pop[idx1] + (1 - alpha) * Pop[idx2], lb, ub)
            off2 = np.clip(alpha * Pop[idx2] + (1 - alpha) * Pop[idx1], lb, ub)
            CrossPop.extend([off1, off2])

        CrossPop = np.array(CrossPop) if len(CrossPop) > 0 else np.empty((0, dim))
        MutatPop = np.random.uniform(lb, ub, (MutatNum, dim)) if MutatNum > 0 else np.empty((0, dim))

        Pop_list = [ElitPop]
        if len(CrossPop) > 0: Pop_list.append(CrossPop)
        if len(MutatPop) > 0: Pop_list.append(MutatPop)
        Pop = np.vstack(Pop_list)

        Cost = np.array([obj_func(Pop[i]) for i in range(PopSize)])
        sort_idx = np.argsort(Cost)
        Pop, Cost = Pop[sort_idx], Cost[sort_idx]
        convergence[Iter] = Cost[0]

    return Pop[0], Cost[0], convergence



def ITSA_func_proposed(obj_func, dim, pop_size, max_gen, lb, ub):
    N, D = pop_size, dim
    low, high = int(np.ceil(0.1 * N)), int(np.ceil(0.25 * N))
    ST = 0.1

    theta_pip = 3
    theta_rot = 6
    K_bod = min(3, N)

    trees = np.random.uniform(lb, ub, (N, D))
    obj = np.array([obj_func(trees[i]) for i in range(N)])
    W = np.zeros(N, dtype=int)  # 停滞计数器 W_i

    best_idx = np.argmin(obj)
    best = obj[best_idx]
    best_params = trees[best_idx].copy()
    convergence = np.zeros(max_gen)

    for t in range(max_gen):
        sort_indices = np.argsort(obj)
        sorted_obj = obj[sort_indices]
        sorted_trees = trees[sort_indices]

        # 创新点 1: 董事会愿景 (BoD Vision)
        bod_trees = sorted_trees[:K_bod]
        bod_obj = sorted_obj[:K_bod]
        weights = np.exp(-(bod_obj - bod_obj[0]) / (bod_obj[0] + 1e-8))
        weights /= np.sum(weights)
        V_bod = np.sum(bod_trees * weights[:, np.newaxis], axis=0)

        # 划分 Senior (前50%)
        senior_set = set(sort_indices[:N // 2])
        w_decay = 1.0 - (t / max_gen)  # 动态收敛因子

        for i in range(N):
            ns = np.random.randint(low, high + 1)
            seeds = np.zeros((ns, D))

            for j in range(ns):
                if W[i] >= theta_rot:
                    # 创新点 3: 重组 (Lévy jump)
                    beta = 1.5
                    sigma = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) / (
                                math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
                    u = np.random.randn(D) * sigma
                    v = np.random.randn(D)
                    step = u / np.abs(v) ** (1 / beta)
                    seeds[j] = trees[i] + w_decay * step * (V_bod - trees[i])

                elif W[i] >= theta_pip:
                    # 创新点 3: PIP (Gaussian around BoD)
                    seeds[j] = trees[i] + np.random.normal(0, 0.5 * w_decay, D) * (V_bod - trees[i])

                else:
                    # 创新点 2 + 稀疏掩码
                    r = np.random.randint(0, N)
                    while r == i: r = np.random.randint(0, N)

                    # 只有 ST 概率的维度进行高级更新，其他维度保守探索
                    mask = np.random.rand(D) < ST

                    if i in senior_set:
                        # Senior: 协作创新，受 BoD 指导
                        step1 = (V_bod - trees[r]) * np.random.uniform(-1, 1, D)
                        step2 = (trees[i] - trees[r]) * np.random.uniform(-1, 1, D)
                    else:
                        # Junior: 导师制，受 Senior 指导
                        mentor_idx = np.random.choice(list(senior_set))
                        step1 = (trees[mentor_idx] - trees[i]) * np.random.uniform(0, 2, D)
                        step2 = (trees[i] - trees[r]) * np.random.uniform(-1, 1, D)

                    # 向量化执行掩码更新
                    seeds[j] = trees[i] + np.where(mask, step1, step2)

            seeds = np.clip(seeds, lb, ub)

            seeds_obj = np.array([obj_func(seeds[j]) for j in range(ns)])
            best_seed_idx = np.argmin(seeds_obj)

            if seeds_obj[best_seed_idx] < obj[i]:
                trees[i] = seeds[best_seed_idx].copy()
                obj[i] = seeds_obj[best_seed_idx]
                W[i] = 0
            else:
                W[i] += 1

            if obj[i] < best:
                best = obj[i]
                best_params = trees[i].copy()

        convergence[t] = best

    return best_params, best, convergence
# ==============================================================================
# 第二部分：CEC2014自动评测
# ==============================================================================
def run_full_cec_benchmark():
    print("================================================================")

    DIM = 50
    POP_SIZE = 30
    MAX_GEN = 500
    RUNS = 5

    LB, UB = -100.0, 100.0

    # 评测前 5 个函数
    TEST_FUNCTIONS = range(1, 31)

    algorithms = {
        'ITSA (Proposed)': ITSA_func_proposed,
        'TSA': TSA_func,
        'STSA': STSA_func,
        'EST-TSA': EST_TSA_func,
        'RSA': RSA_func,
        'BOA': BOA_func,
        'GA': GA_func
    }

    results_table = {alg_name: [] for alg_name in algorithms.keys()}
    results_table['Function'] = []

    for f_idx in TEST_FUNCTIONS:
        func_name = f"F{f_idx}2014"
        print(f"\n正在评测 {func_name} (维度={DIM}, {RUNS}次独立运行) ...")

        try:
            funcs = opfunu.get_functions_by_classname(func_name)
            cec_func = funcs[0](ndim=DIM)
        except Exception as e:
            print(f"初始化 {func_name} 失败: {e}")
            continue

        results_table['Function'].append(func_name)

        plt.style.use('seaborn-v0_8-whitegrid')
        fig, ax = plt.subplots(figsize=(10, 6), dpi=300)
        colors = ['#d62728', '#1f77b4', '#ff7f0e', '#2ca02c', '#9467bd', '#8c564b', '#e377c2']
        markers = ['o', 's', '^', 'D', 'P', 'X', '*']
        x_axis = np.arange(1, MAX_GEN + 1)

        # 核心保证：为每一个函数单独生成一组固定的测试种子
        run_seeds = [int(time.time() * 1000) % 2 ** 32 + r for r in range(RUNS)]

        for idx_alg, (alg_name, alg_func) in enumerate(algorithms.items()):
            run_errors = []
            run_curves = []

            print(f"  > 正在运行 {alg_name:<16} ...", end="", flush=True)

            for r in range(RUNS):
                np.random.seed(run_seeds[r])

                _, best_val, curve = alg_func(cec_func.evaluate, DIM, POP_SIZE, MAX_GEN, LB, UB)

                error = abs(best_val - (f_idx * 100))
                curve_error = np.abs(np.array(curve) - (f_idx * 100))

                run_errors.append(error)
                run_curves.append(curve_error)

            avg_error = np.mean(run_errors)
            avg_curve = np.mean(run_curves, axis=0)

            results_table[alg_name].append(avg_error)
            print(f"\r  > {alg_name:<16} 5次平均误差: {avg_error:.4e}")

            safe_curve = np.maximum(avg_curve, 1e-10)
            log_curve = np.log10(safe_curve)

            lw = 3.0 if 'ITSA' in alg_name else 1.5
            ls = '-' if 'ITSA' in alg_name else '--'

            ax.plot(x_axis, log_curve, label=alg_name, color=colors[idx_alg],
                    linewidth=lw, linestyle=ls, marker=markers[idx_alg], markevery=MAX_GEN // 10)

        ax.set_xlabel('Iteration', fontsize=12, fontweight='bold')
        ax.set_ylabel(f'Log10(Error) on {func_name}', fontsize=12, fontweight='bold')
        ax.set_title(f'Convergence Curves Comparison on {func_name} (Dim={DIM})', fontsize=14, fontweight='bold')
        ax.legend(fontsize=10, frameon=True, edgecolor='black', loc='upper right')
        plt.tight_layout()
        plot_filename = f'Convergence_{func_name}.png'
        plt.savefig(plot_filename)
        plt.close()

    if results_table['Function']:
        print("\n" + "=" * 60)
        print("=" * 60)
        df_results = pd.DataFrame(results_table)
        cols = ['Function'] + list(algorithms.keys())
        df_results = df_results[cols]
        print(df_results.to_markdown(index=False))
        df_results.to_csv("CEC2014_Table1_50D_Results.csv", index=False)
        print("\n完整表格已导出为: CEC2014_Table1_50D_Results.csv")


if __name__ == "__main__":
    run_full_cec_benchmark()