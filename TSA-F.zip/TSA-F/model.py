import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class PureMambaBlock(nn.Module):


    def __init__(self, d_model, d_state=16, d_conv=4, expand=2):
        super().__init__()
        self.d_inner = expand * d_model
        self.d_state = d_state
        self.dt_rank = math.ceil(d_model / 16)

        # 输入投影层
        self.in_proj = nn.Linear(d_model, self.d_inner * 2, bias=False)

        # 因果一维卷积
        self.conv1d = nn.Conv1d(
            in_channels=self.d_inner,
            out_channels=self.d_inner,
            bias=True,
            kernel_size=d_conv,
            groups=self.d_inner,
            padding=d_conv - 1,
        )

        # 状态空间模型 (SSM) 的参数投影
        self.x_proj = nn.Linear(self.d_inner, self.dt_rank + self.d_state * 2, bias=False)
        self.dt_proj = nn.Linear(self.dt_rank, self.d_inner, bias=True)

        # 核心 SSM 权重
        A = torch.arange(1, self.d_state + 1, dtype=torch.float32).repeat(self.d_inner, 1)
        self.A_log = nn.Parameter(torch.log(A))
        self.D = nn.Parameter(torch.ones(self.d_inner))

        # 输出投影层
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

    def forward(self, x):

        b, l, _ = x.shape

        # 1. 投影与分支
        x_and_res = self.in_proj(x)
        x_and_res = x_and_res.transpose(1, 2)
        x, res = x_and_res.split(self.d_inner, dim=1)

        # 2. 卷积处理
        x = self.conv1d(x)[:, :, :l]
        x = F.silu(x)

        # 3. 准备 Selective SSM 的参数
        x_t = x.transpose(1, 2)
        x_proj = self.x_proj(x_t)
        dt, B, C = x_proj.split([self.dt_rank, self.d_state, self.d_state], dim=-1)

        dt = F.softplus(self.dt_proj(dt))
        A = -torch.exp(self.A_log)

        # 4. 选择性扫描 (Selective Scan Loop)
        y = torch.empty((b, l, self.d_inner), device=x.device)
        h = torch.zeros((b, self.d_inner, self.d_state), device=x.device)

        for t in range(l):
            dt_t = dt[:, t, :].unsqueeze(-1)
            A_t = dt_t * A
            B_t = B[:, t, :].unsqueeze(1)
            C_t = C[:, t, :].unsqueeze(1)
            x_t_slice = x_t[:, t, :].unsqueeze(-1)

            # 状态更新方程 (对应论文核心机制)
            h = torch.exp(A_t) * h + dt_t * B_t * x_t_slice
            y[:, t, :] = (h * C_t).sum(dim=-1)

        # 5. 残差与输出
        y = y + x_t * self.D
        y = y * F.silu(res.transpose(1, 2))
        out = self.out_proj(y)

        return out


class ITSAMambaModel(nn.Module):
    def __init__(self,
                 d_input=6,  # 输入特征数 (OHLCV + LLM_Sentiment = 6)
                 d_model=64,  # 模型的隐藏层维度
                 n_layer=2,  # 待 ITSA 优化的层数
                 d_state=16,  # 待 ITSA 优化的 SSM 状态扩展因子
                 d_conv=4,  # 待 ITSA 优化的局部卷积核大小
                 expand=2):
        super().__init__()

        self.d_model = d_model
        self.embedding = nn.Linear(d_input, d_model)

        self.layers = nn.ModuleList([
            PureMambaBlock(
                d_model=d_model,
                d_state=d_state,
                d_conv=d_conv,
                expand=expand
            ) for _ in range(n_layer)
        ])

        self.norm = nn.LayerNorm(d_model)
        self.fc_out = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.embedding(x)
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)

        last_step_out = x[:, -1, :]
        out = self.fc_out(last_step_out)
        return out


if __name__ == "__main__":
    batch_size = 64
    window_size = 60
    features = 6

    # 模拟输入张量
    dummy_input = torch.randn(batch_size, window_size, features)

    print("正在实例化 纯PyTorch版 Mamba 模型...")
    # 这里的参数将由后续的 ITSA 提供
    model = ITSAMambaModel(d_input=features, d_model=32, n_layer=2, d_state=16, d_conv=4)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    dummy_input = dummy_input.to(device)

    output = model(dummy_input)

    print("-" * 40)
    print(f"输入张量形状: {dummy_input.shape}")
    print(f"输出张量形状: {output.shape} (期望值: [64, 1])")
    print(f"当前运行设备: {device}")
    print("-" * 40)