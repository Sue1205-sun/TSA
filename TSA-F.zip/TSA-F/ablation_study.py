import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error, mean_absolute_percentage_error

from data_loader import get_ssec_data, calculate_llm_sentiment_proxy, get_dataloaders
from model import ITSAMambaModel
from itsa_optimizer import ITSAOptimizer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train_and_evaluate(model, train_loader, test_loader, d_input, scaler, name, epochs=50):

    print(f"\n🔥 正在训练变体: {name}...")
    model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=1e-4)
    criterion = nn.MSELoss()
    model.train()

    for epoch in range(epochs):
        for batch_X, batch_y in train_loader:
            batch_X = batch_X[:, :, :d_input].to(device)
            batch_y = batch_y.to(device)
            optimizer.zero_grad()
            loss = criterion(model(batch_X), batch_y)
            loss.backward()
            optimizer.step()

    model.eval()
    preds = []
    trues = []
    with torch.no_grad():
        for batch_X, batch_y in test_loader:
            batch_X = batch_X[:, :, :d_input].to(device)
            out = model(batch_X).cpu().numpy().flatten()
            preds.extend(out)
            trues.extend(batch_y.numpy().flatten())

    close_min, close_max = scaler.data_min_[3], scaler.data_max_[3]
    preds_real = np.array(preds) * (close_max - close_min) + close_min
    trues_real = np.array(trues) * (close_max - close_min) + close_min

    rmse = np.sqrt(mean_squared_error(trues_real, preds_real))
    mae = mean_absolute_error(trues_real, preds_real)
    mape = mean_absolute_percentage_error(trues_real, preds_real) * 100  # 转为百分比

    print(f"✅ {name} 评估完成 -> RMSE: {rmse:.2f}, MAE: {mae:.2f}, MAPE: {mape:.3f}%")
    return rmse, mae, mape


def plot_ablation_results(results_dict):

    plt.style.use('seaborn-v0_8-whitegrid')
    fig, axes = plt.subplots(1, 3, figsize=(18, 6), dpi=300)

    metrics = ['RMSE (pts)', 'MAE (pts)', 'MAPE (%)']
    model_names = ['Mamba\n(Base)', 'Mamba\n+LLM', 'ITSA+Mamba\n(w/o LLM)', 'ITSA+Mamba\n+LLM\n(Proposed)']

    colors = ['#aec7e8', '#7cb5ec', '#4b96d1', '#d62728']

    for i, metric in enumerate(metrics):
        ax = axes[i]
        values = [results_dict[m][i] for m in model_names]

        bars = ax.bar(model_names, values, color=colors, width=0.5)
        ax.set_ylabel(metric, fontsize=12, fontweight='bold')
        ax.tick_params(axis='x', labelsize=10)
        ax.grid(axis='y', linestyle='--', alpha=0.5)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

        for bar in bars:
            height = bar.get_height()
            label_text = f'{height:.1f}' if i < 2 else f'{height:.3f}'
            ax.text(bar.get_x() + bar.get_width() / 2., height + (max(values) * 0.02),
                    label_text, ha='center', va='bottom', fontsize=11, fontweight='bold')

        base_val = values[0]
        proposed_val = values[-1]
        drop_pct = ((base_val - proposed_val) / base_val) * 100

        bbox_props = dict(boxstyle="round,pad=0.3", fc="white", ec="#d62728", lw=1.5)
        ax.text(0.95, 0.95, f'↓ {drop_pct:.1f}%', transform=ax.transAxes, fontsize=12,
                fontweight='bold', color='#d62728', ha='right', va='top', bbox=bbox_props)

    plt.tight_layout()
    plt.savefig('fig4_ssec_ablation.png', bbox_inches='tight')
    plt.show()
    print("🎉 图表已保存为 fig4_ssec_ablation.png")


def main():
    batch_size, window_size = 64, 60
    train_loader_llm, test_loader_llm, scaler = get_dataloaders(batch_size, window_size, start_date="2015-01-01",
                                                                include_sentiment=True)
    train_loader_base, test_loader_base, _ = get_dataloaders(batch_size, window_size, start_date="2015-01-01",
                                                             include_sentiment=False)

    EPOCHS = 100

    opt_d_model, opt_n_layer, opt_d_state, opt_d_conv = 50, 1, 24, 5
    base_d_model, base_n_layer, base_d_state, base_d_conv = 16, 1, 16, 2

    results = {}


    m1 = ITSAMambaModel(d_input=5, d_model=base_d_model, n_layer=base_n_layer, d_state=base_d_state, d_conv=base_d_conv)
    results['Mamba\n(Base)'] = train_and_evaluate(m1, train_loader_base, test_loader_base, d_input=5, scaler=scaler,
                                                  name="Mamba (Base)", epochs=EPOCHS)

    m2 = ITSAMambaModel(d_input=6, d_model=base_d_model, n_layer=base_n_layer, d_state=base_d_state, d_conv=base_d_conv)
    results['Mamba\n+LLM'] = train_and_evaluate(m2, train_loader_llm, test_loader_llm, d_input=6, scaler=scaler,
                                                name="Mamba + LLM", epochs=EPOCHS)

    m3 = ITSAMambaModel(d_input=5, d_model=opt_d_model, n_layer=opt_n_layer, d_state=opt_d_state, d_conv=opt_d_conv)
    results['ITSA+Mamba\n(w/o LLM)'] = train_and_evaluate(m3, train_loader_base, test_loader_base, d_input=5,
                                                          scaler=scaler, name="ITSA + Mamba (w/o LLM)", epochs=EPOCHS)

    m4 = ITSAMambaModel(d_input=6, d_model=opt_d_model, n_layer=opt_n_layer, d_state=opt_d_state, d_conv=opt_d_conv)
    results['ITSA+Mamba\n+LLM\n(Proposed)'] = train_and_evaluate(m4, train_loader_llm, test_loader_llm, d_input=6,
                                                                 scaler=scaler, name="ITSA + Mamba + LLM (Proposed)",
                                                                 epochs=EPOCHS)

    plot_ablation_results(results)


if __name__ == "__main__":
    """
    dummy_results = {
        'Mamba\n(Base)': (71.4, 51.2, 0.597),
        'Mamba\n+LLM': (62.7, 46.2, 0.511),
        'ITSA+Mamba\n(w/o LLM)': (51.0, 40.6, 0.457),
        'ITSA+Mamba\n+LLM\n(Proposed)': (41.0, 33.1, 0.387)
    }
    plot_ablation_results(dummy_results)
    """
    main()