import numpy as np
import math


class ITSAOptimizer:
    def __init__(self,
                 obj_func,  # 目标函数
                 dim=4,  # 优化维度 (d_model, n_layer, d_state, d_conv)
                 pop_size=20,  # 种群规模
                 max_gen=50,  # 最大迭代次数
                 bounds=None,  # 各维度的边界范围 [(min, max), ...]
                 theta_pip=3,  # PIP 轻度停滞阈值
                 theta_rot=6,  # Reorganization 重度停滞阈值
                 k_bod=3,  # 董事会 (BoD) 成员数量
                 eta=1.0):  # 玻尔兹曼分布的逆温度参数

        self.obj_func = obj_func
        self.dim = dim
        self.N = pop_size
        self.max_gen = max_gen
        self.bounds = np.array(bounds)
        self.theta_pip = theta_pip
        self.theta_rot = theta_rot
        self.K = min(k_bod, self.N)
        self.eta = eta

        # 种子数量的浮动范围
        self.low = math.ceil(0.1 * self.N)
        self.high = math.ceil(0.25 * self.N)

        # 初始化种群
        self.trees = np.zeros((self.N, self.dim))
        self.W = np.zeros(self.N, dtype=int)  # 停滞计数器 W_i
        self.fitness = np.zeros(self.N)

        # 记录全局最优
        self.gbest_params = np.zeros(self.dim)
        self.gbest_val = float('inf')
        self.convergence_curve = []

    def _init_population(self):
        for i in range(self.N):
            for j in range(self.dim):
                self.trees[i, j] = np.random.uniform(self.bounds[j, 0], self.bounds[j, 1])
            self.fitness[i] = self.obj_func(self.trees[i])

            if self.fitness[i] < self.gbest_val:
                self.gbest_val = self.fitness[i]
                self.gbest_params = self.trees[i].copy()

    def _levy_flight(self, beta=1.5):
        sigma = (math.gamma(1 + beta) * math.sin(math.pi * beta / 2) /
                 (math.gamma((1 + beta) / 2) * beta * 2 ** ((beta - 1) / 2))) ** (1 / beta)
        u = np.random.normal(0, sigma, self.dim)
        v = np.random.normal(0, 1, self.dim)
        step = u / (np.abs(v) ** (1 / beta))
        return step

    def optimize(self):
        self._init_population()

        for t in range(self.max_gen):
            sort_indices = np.argsort(self.fitness)
            sorted_fitness = self.fitness[sort_indices]
            sorted_trees = self.trees[sort_indices]

            bod_trees = sorted_trees[:self.K]
            bod_fitness = sorted_fitness[:self.K]

            f_min = bod_fitness[0] + 1e-8
            exponent = -self.eta * (bod_fitness / f_min)
            weights = np.exp(exponent)
            weights = weights / np.sum(weights)

            V_bod = np.sum(bod_trees * weights[:, np.newaxis], axis=0)

            senior_indices = sort_indices[:self.N // 2]

            for i in range(self.N):
                ns = np.random.randint(self.low, self.high + 1)
                seeds = np.zeros((ns, self.dim))
                seeds_fitness = np.zeros(ns)

                T_i = self.trees[i]

                for j in range(ns):
                    S_ij = np.zeros(self.dim)

                    if self.W[i] >= self.theta_rot:
                        alpha = np.random.uniform(0.5, 1.5)
                        step = self._levy_flight()
                        S_ij = T_i + alpha * step * (V_bod - T_i)

                    elif self.W[i] >= self.theta_pip:
                        G = np.random.normal(0, 0.1, self.dim)  # 协方差较小的高斯扰动
                        S_ij = T_i + G * (V_bod - T_i)

                    elif i in senior_indices:
                        F_t = 1.0 - (t / self.max_gen)  # 动态衰减因子
                        r1, r2 = np.random.rand(), np.random.rand()
                        idx1, idx2 = np.random.choice(self.N, 2, replace=False)
                        T_r1, T_r2 = self.trees[idx1], self.trees[idx2]

                        S_ij = T_i + F_t * (r1 * (V_bod - T_i) + r2 * (T_r1 - T_r2))

                    else:
                        mentor_idx = np.random.choice(senior_indices)
                        T_mentor = self.trees[mentor_idx]
                        Lambda = np.random.rand()
                        epsilon = np.random.rand(self.dim)

                        S_ij = T_i + Lambda * epsilon * (T_mentor - T_i)

                    S_ij = np.clip(S_ij, self.bounds[:, 0], self.bounds[:, 1])
                    seeds[j] = S_ij

                    seeds_fitness[j] = self.obj_func(S_ij)

                best_seed_idx = np.argmin(seeds_fitness)
                if seeds_fitness[best_seed_idx] < self.fitness[i]:
                    self.trees[i] = seeds[best_seed_idx]
                    self.fitness[i] = seeds_fitness[best_seed_idx]
                    self.W[i] = 0
                else:
                    self.W[i] += 1

                if self.fitness[i] < self.gbest_val:
                    self.gbest_val = self.fitness[i]
                    self.gbest_params = self.trees[i].copy()

            self.convergence_curve.append(self.gbest_val)
            print(f"Iteration {t + 1}/{self.max_gen} - Best RMSE: {self.gbest_val:.4f}")

        print("--- ITSA 优化完成 ---")
        return self.gbest_params, self.gbest_val, self.convergence_curve


# ================= 测试代码 =================
if __name__ == "__main__":

    def dummy_mamba_evaluate(params):
        d_model = int(params[0])
        n_layer = int(params[1])
        d_state = int(params[2])
        d_conv = int(params[3])


        target = np.array([64, 4, 16, 4])
        current = np.array([d_model, n_layer, d_state, d_conv])

        fake_rmse = np.sum((current - target) ** 2) + np.random.uniform(0, 5)
        return fake_rmse


    param_bounds = [
        (16, 128),  # d_model 范围
        (1, 8),  # n_layer 范围
        (8, 64),  # d_state 范围
        (2, 8)  # d_conv 范围
    ]

    optimizer = ITSAOptimizer(
        obj_func=dummy_mamba_evaluate,
        dim=4,
        pop_size=15,
        max_gen=20,
        bounds=param_bounds
    )

    best_params, best_val, curve = optimizer.optimize()

    print("\n✅ 优化结果：")
    print(f"最佳超参数 (连续值): {best_params}")
    print(
        f"最佳超参数 (转整数): [d_model={int(best_params[0])}, n_layer={int(best_params[1])}, d_state={int(best_params[2])}, d_conv={int(best_params[3])}]")
    print(f"最低 RMSE (Fitness): {best_val:.4f}")