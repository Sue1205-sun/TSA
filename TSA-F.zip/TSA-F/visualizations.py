import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.dates as mdates

from data_loader import get_ssec_data, calculate_llm_sentiment_proxy


def plot_price_vs_sentiment(df):

    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax1 = plt.subplots(figsize=(14, 6), dpi=300)

    color_price = '#1f77b4'
    ax1.plot(df.index, df['Close'], color=color_price, linewidth=2, label='Close Price (Real)')
    ax1.set_xlabel('Date', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Close Price (pts)', color=color_price, fontsize=12, fontweight='bold')
    ax1.tick_params(axis='y', labelcolor=color_price)
    ax1.grid(True, linestyle='--', alpha=0.5)

    ax2 = ax1.twinx()
    color_sentiment_line = '#ff7f0e'

    ax2.plot(df.index, df['LLM_Sentiment'], color=color_sentiment_line, linewidth=1, alpha=0.5,
             label='LLM Sentiment Score')

    ax2.fill_between(df.index, 0, df['LLM_Sentiment'],
                     where=(df['LLM_Sentiment'] >= 0),
                     color='#d62728', alpha=0.3, interpolate=True, label='Positive Sentiment')

    ax2.fill_between(df.index, 0, df['LLM_Sentiment'],
                     where=(df['LLM_Sentiment'] < 0),
                     color='#2ca02c', alpha=0.3, interpolate=True, label='Negative Sentiment')

    ax2.set_ylabel('LLM Sentiment Score (Proxy)', color=color_sentiment_line, fontsize=12, fontweight='bold')
    ax2.tick_params(axis='y', labelcolor=color_sentiment_line)

    ax2.axhline(0, color='black', linewidth=0.8, linestyle='-.', alpha=0.5)


    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc='upper left', ncol=4, frameon=True, fontsize=10)

    ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.setp(ax1.xaxis.get_majorticklabels(), rotation=15)

    plt.title('SSEC Price vs. LLM Sentiment Proxy', fontsize=14, fontweight='bold', pad=15)
    plt.tight_layout()
    plt.savefig('fig1_ssec_sentiment_price.png', bbox_inches='tight')
    plt.show()


def plot_feature_correlation(df):

    fig, ax = plt.subplots(figsize=(8, 7), dpi=300)

    features = ['Open', 'High', 'Low', 'Close', 'Volume', 'LLM_Sentiment']
    corr_matrix = df[features].corr()

    sns.heatmap(corr_matrix,
                annot=False,
                cmap='RdYlGn',
                center=0,
                vmin=-1, vmax=1,
                square=True,
                linewidths=0.5,
                cbar_kws={"shrink": .8, "label": "Pearson r"},
                ax=ax)

    for i in range(len(features)):
        for j in range(len(features)):
            val = corr_matrix.iloc[i, j]
            if pd.notna(val):
                text_color = "white" if abs(val) > 0.6 else "black"

                ax.text(j + 0.5, i + 0.5, f"{val:.3f}",
                        ha='center', va='center',
                        color=text_color, fontsize=10, fontweight='medium')


    plt.xticks(rotation=45, ha='right', fontsize=10)
    plt.yticks(rotation=0, fontsize=10)

    plt.title('Feature Correlation Heatmap', fontsize=14, fontweight='bold', pad=15)
    plt.tight_layout()
    plt.savefig('fig2_ssec_correlation_heatmap.png', bbox_inches='tight')
    plt.show()


if __name__ == "__main__":
    df_raw = get_ssec_data()
    df_features = calculate_llm_sentiment_proxy(df_raw)

    print("\n绘制 1/2: 价格与情绪动态双轴图 (Figure 4)...")
    plot_price_vs_sentiment(df_features)

    print("\n绘制 2/2: 特征相关性热力图 (Figure 5)...")
    plot_feature_correlation(df_features)

    print("\n图表已生成并在根目录保存为 PNG 格式！")