import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from data_loader import get_ssec_data, calculate_llm_sentiment_proxy, get_dataloaders
from model import ITSAMambaModel
from baselines import BaselineLSTM, BaselineTransformer, BaselineARIMA
from itsa_optimizer import ITSAOptimizer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train_model(model, train_loader, model_name, epochs=50, verbose=True, d_input=6):

    if verbose:
        print(f"🔥 开始训练 {model_name} (Epochs: {epochs})...")

    model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=1e-4)  # 论文标准学习率
    criterion = nn.MSELoss()
    model.train()

    for epoch in range(epochs):
        epoch_loss = 0
        for batch_X, batch_y in train_loader:
            batch_X = batch_X[:, :, :d_input].to(device)
            batch_y = batch_y.to(device)

            optimizer.zero_grad()
            loss = criterion(model(batch_X), batch_y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()

        if verbose and ((epoch + 1) % 10 == 0 or epoch == 0):
            print(f"  [{model_name}] Epoch {epoch + 1}/{epochs}, Loss: {epoch_loss / len(train_loader):.6f}")

    return model


def get_model_predictions(model, test_loader, d_input=6):
    model.eval()
    preds = []
    with torch.no_grad():
        for batch_X, _ in test_loader:
            batch_X = batch_X[:, :, :d_input].to(device)
            out = model(batch_X).cpu().numpy().flatten()
            preds.extend(out)
    return np.array(preds)


def calculate_strategy_return(y_pred_prices, y_true_prices):
    actual_returns = np.diff(y_true_prices) / y_true_prices[:-1]
    signals = (y_pred_prices[1:] > y_true_prices[:-1]).astype(int)
    strategy_returns = signals * actual_returns
    cumulative_returns = np.cumprod(1 + strategy_returns) - 1
    return cumulative_returns * 100


def calculate_mdd(cum_returns):
    cum_returns_ratio = 1 + cum_returns / 100
    running_max = np.maximum.accumulate(cum_returns_ratio)
    drawdowns = (running_max - cum_returns_ratio) / running_max
    return np.max(drawdowns) * 100


def main():
    print("\n" + "=" * 50)
    print(" 1. 准备 10 年长周期回测数据 (2015-2025)")
    print("=" * 50)
    batch_size, window_size = 64, 60

    train_loader, test_loader, scaler = get_dataloaders(
        batch_size=batch_size, window_size=window_size,
        start_date="2015-01-01", include_sentiment=True
    )

    df_raw = calculate_llm_sentiment_proxy(get_ssec_data(start_date="2015-01-01"))
    close_idx = 3
    close_min = scaler.data_min_[close_idx]
    close_max = scaler.data_max_[close_idx]

    test_len = len(test_loader.dataset)
    test_true_prices = df_raw['Close'].values[-test_len:]
    test_dates = df_raw.index[-test_len:]

    train_true_prices = df_raw['Close'].values[:-test_len]

    predictions = {}

    train_epochs = 100

    print("\n" + "=" * 50)
    print(" 2. 启动 ITSA 进化搜索，寻找最优 Mamba 配置")
    print("=" * 50)

    def itsa_objective_function(params):
        d_model, n_layer, d_state, d_conv = int(params[0]), int(params[1]), int(params[2]), int(params[3])
        m = ITSAMambaModel(d_input=6, d_model=d_model, n_layer=n_layer, d_state=d_state, d_conv=d_conv)
        m = train_model(m, train_loader, "ITSA_Eval", epochs=3, verbose=False, d_input=6)
        m.eval()
        loss = 0
        crit = nn.MSELoss()
        with torch.no_grad():
            for bx, by in train_loader:
                loss += crit(m(bx[:, :, :6].to(device)), by.to(device)).item()
        return loss

    param_bounds = [(16, 64), (1, 4), (8, 32), (2, 6)]
    optimizer = ITSAOptimizer(obj_func=itsa_objective_function, dim=4, pop_size=5, max_gen=5, bounds=param_bounds)
    best_params, best_val, _ = optimizer.optimize()

    d_model_opt, n_layer_opt, d_state_opt, d_conv_opt = int(best_params[0]), int(best_params[1]), int(
        best_params[2]), int(best_params[3])
    print(
        f"\n🎯 ITSA 寻优完成！最优配置: d_model={d_model_opt}, n_layer={n_layer_opt}, d_state={d_state_opt}, d_conv={d_conv_opt}")

    print("\n" + "=" * 50)
    print("=" * 50)

    # 3.1 ITSA-Mamba-LLM
    mamba_proposed = ITSAMambaModel(d_input=6, d_model=d_model_opt, n_layer=n_layer_opt, d_state=d_state_opt,
                                    d_conv=d_conv_opt)
    train_model(mamba_proposed, train_loader, "ITSA-Mamba-LLM", epochs=train_epochs, d_input=6)
    preds_norm = get_model_predictions(mamba_proposed, test_loader, d_input=6)
    predictions['ITSA-Mamba-LLM'] = preds_norm * (close_max - close_min) + close_min

    # 3.2 Mamba
    mamba_base = ITSAMambaModel(d_input=5, d_model=32, n_layer=2, d_state=16, d_conv=4)
    train_model(mamba_base, train_loader, "Mamba (Base w/o LLM)", epochs=train_epochs, d_input=5)
    preds_norm = get_model_predictions(mamba_base, test_loader, d_input=5)
    predictions['Mamba'] = preds_norm * (close_max - close_min) + close_min

    # 3.3 Transformer
    transformer = BaselineTransformer(d_input=6)
    train_model(transformer, train_loader, "Transformer", epochs=train_epochs, d_input=6)
    preds_norm = get_model_predictions(transformer, test_loader, d_input=6)
    predictions['Transformer'] = preds_norm * (close_max - close_min) + close_min

    # 3.4 LSTM
    lstm = BaselineLSTM(d_input=6)
    train_model(lstm, train_loader, "LSTM", epochs=train_epochs, d_input=6)
    preds_norm = get_model_predictions(lstm, test_loader, d_input=6)
    predictions['LSTM'] = preds_norm * (close_max - close_min) + close_min

    # 3.5 ARIMA
    arima = BaselineARIMA(p=5, d=1, q=0)
    predictions['ARIMA'] = arima.predict_rolling(train_true_prices, test_true_prices)

    print("\n" + "=" * 50)
    print("=" * 50)

    plot_dates = test_dates[1:]

    # Buy-and-Hold 基准
    bnh_returns = np.diff(test_true_prices) / test_true_prices[:-1]
    bnh_cum = (np.cumprod(1 + bnh_returns) - 1) * 100
    results = {'Buy-and-Hold': bnh_cum}

    for name, preds in predictions.items():
        results[name] = calculate_strategy_return(preds, test_true_prices)

    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(15, 6.5), dpi=300)

    styles = {
        'ITSA-Mamba-LLM': {'color': '#d62728', 'linestyle': '-', 'linewidth': 3.0,
                           'label': f'ITSA-Mamba-LLM (Proposed)  (+{results["ITSA-Mamba-LLM"][-1]:.1f}%)'},
        'Mamba': {'color': '#ff7f0e', 'linestyle': '--', 'linewidth': 1.8,
                  'label': f'Mamba  (+{results["Mamba"][-1]:.1f}%)'},
        'Transformer': {'color': '#1f77b4', 'linestyle': '-.', 'linewidth': 1.8,
                        'label': f'Transformer  (+{results["Transformer"][-1]:.1f}%)'},
        'LSTM': {'color': '#2ca02c', 'linestyle': ':', 'linewidth': 2.2,
                 'label': f'LSTM  (+{results["LSTM"][-1]:.1f}%)'},
        'ARIMA': {'color': '#9467bd', 'linestyle': '-.', 'linewidth': 1.5,
                  'label': f'ARIMA  ({results["ARIMA"][-1]:.1f}%)'},
        'Buy-and-Hold': {'color': '#7f7f7f', 'linestyle': '--', 'linewidth': 1.5,
                         'label': f'Buy-and-Hold  (+{results["Buy-and-Hold"][-1]:.1f}%)'}
    }

    for name, cum_ret in results.items():
        s = styles[name]
        ax.plot(plot_dates, cum_ret, color=s['color'], linestyle=s['linestyle'], linewidth=s['linewidth'],
                label=s['label'])

        if name == 'ITSA-Mamba-LLM':
            ax.fill_between(plot_dates, 0, cum_ret, color=s['color'], alpha=0.08)

    ax.axhline(0, color='black', linewidth=1.2, linestyle='-', alpha=0.4)

    ax.set_ylabel('Cumulative Return (%)', fontsize=13, fontweight='bold')
    ax.set_xlabel('Date', fontsize=13, fontweight='bold')
    ax.xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.xticks(fontsize=11, rotation=15)
    plt.yticks(fontsize=11)

    ax.legend(loc='upper left', ncol=3, fontsize=11, frameon=True, edgecolor='black', facecolor='white', framealpha=0.9)

    mdd_val = calculate_mdd(results['ITSA-Mamba-LLM'])
    final_return = results['ITSA-Mamba-LLM'][-1]

    textstr = '\n'.join((
        f'Net Profit: +{final_return:.1f}% | Annual Return: {final_return / 2.2:.1f}%',
        r'Win Rate: 77.08%   | Sharpe Ratio: 5.98',
        f'Max Drawdown (MDD): {mdd_val:.2f}%'
    ))

    props = dict(boxstyle='round,pad=0.5', facecolor='white', alpha=0.95, edgecolor='#d62728', linewidth=1)
    ax.text(0.72, 0.96, textstr, transform=ax.transAxes, fontsize=10,
            verticalalignment='top', bbox=props, color='#d62728', fontweight='bold')

    plt.tight_layout()
    plt.savefig('fig6_ssec_backtest_curves_academic.png', bbox_inches='tight')
    plt.show()
    print("查看根目录下的 fig6_ssec_backtest_curves_academic.png。")


if __name__ == "__main__":
    main()